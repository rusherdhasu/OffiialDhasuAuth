import requests
import subprocess
import json
import os

# Configuration
API_BASE_URL = "http://217.154.173.102:9537/api/"
APP_ID = "7ECD1305"
APP_SECRET = "0bf157628ad00b4376e9fc85332a0508"
CLIENT_VERSION = "1.0.0"

def get_hwid():
    """Fetches the Windows UUID as a unique HWID."""
    try:
        # Using powershell to get UUID
        cmd = 'powershell.exe (Get-WmiObject Win32_ComputerSystemProduct).UUID'
        uuid = subprocess.check_output(cmd, shell=True).decode().strip()
        return uuid
    except Exception as e:
        print(f"Error fetching HWID: {e}")
        return "UNKNOWN_HWID"

def login_with_password(username, password):
    """Authenticates using username and password."""
    url = f"{API_BASE_URL}license/login"
    headers = {
        "App-Id": APP_ID,
        "App-Secret": APP_SECRET,
        "Client-Version": CLIENT_VERSION,
        "User-Agent": f"DhasuAuth-PythonClient/{CLIENT_VERSION}"
    }
    payload = {
        "username": username,
        "password": password,
        "hwid": get_hwid()
    }
    
    try:
        response = requests.post(url, json=payload, headers=headers)
        result = response.json()
        
        if response.status_code == 200:
            expires = result.get("expires", "N/A")
            print(f"✅ Login Successful!")
            print(f"Welcome, {username}")
            print(f"Access Expires: {expires}")
            return True
        else:
            message = result.get("message", "Login Failed")
            reason = result.get("reason", "")
            print(f"❌ Login Failed: {message}")
            if reason:
                print(f"Reason: {reason}")
            return False
            
    except Exception as e:
        print(f"Error connecting to server: {e}")
        return False

def login_with_hwid():
    """Authenticates using the HWID whitelist."""
    url = f"{API_BASE_URL}license/hwid-login"
    headers = {
        "App-Id": APP_ID,
        "App-Secret": APP_SECRET,
        "Client-Version": CLIENT_VERSION,
        "User-Agent": f"DhasuAuth-PythonClient/{CLIENT_VERSION}"
    }
    payload = {
        "hwid": get_hwid()
    }
    
    try:
        response = requests.post(url, json=payload, headers=headers)
        result = response.json()
        
        if response.status_code == 200:
            name = result.get("name", "Authorized User")
            expires = result.get("expires", "Lifetime")
            print(f"✅ HWID Authorized!")
            print(f"Welcome back, {name}")
            print(f"Session: {expires}")
            return True
        else:
            message = result.get("message", "Access Denied")
            print(f"❌ HWID Login Failed: {message}")
            return False
            
    except Exception as e:
        print(f"Error connecting to server: {e}")
        return False

if __name__ == "__main__":
    print("--- DhasuAuth Python Client ---")
    print(f"Your HWID: {get_hwid()}")
    print("-------------------------------")
    
    choice = input("1. Login (User/Pass)\n2. Login (HWID Whitelist)\nSelect: ")
    
    if choice == "1":
        user = input("Username: ")
        pw = input("Password (Enter if none): ")
        login_with_password(user, pw)
    else:
        login_with_hwid()
        
    input("\nPress Enter to exit...")
