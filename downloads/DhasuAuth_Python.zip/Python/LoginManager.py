import requests
import subprocess
import json
import os

class LoginManager:
    # Backend Configuration
    backend_url = "http://217.154.173.102:9537/api/"
    app_id = "7ECD1305"
    app_secret = "0bf157628ad00b4376e9fc85332a0508"
    client_version = "1.0.0"

    @staticmethod
    def get_hwid():
        """Fetches the Windows UUID as a unique HWID."""
        try:
            cmd = 'powershell.exe (Get-WmiObject Win32_ComputerSystemProduct).UUID'
            uuid = subprocess.check_output(cmd, shell=True).decode().strip()
            return uuid
        except:
            return "UNKNOWN_HWID"

    @classmethod
    def login_with_password(cls, username, password):
        """Authenticates using username and password."""
        url = f"{cls.backend_url}license/login"
        headers = {
            "App-Id": cls.app_id,
            "App-Secret": cls.app_secret,
            "Client-Version": cls.client_version,
            "User-Agent": f"DhasuAuth-PythonClient/{cls.client_version}"
        }
        payload = {
            "username": username,
            "password": password,
            "hwid": cls.get_hwid()
        }
        
        try:
            response = requests.post(url, json=payload, headers=headers)
            return response.status_code, response.json()
        except Exception as e:
            return 500, {"message": str(e)}

    @classmethod
    def login_with_hwid(cls):
        """Authenticates using the HWID whitelist."""
        url = f"{cls.backend_url}license/hwid-login"
        headers = {
            "App-Id": cls.app_id,
            "App-Secret": cls.app_secret,
            "Client-Version": cls.client_version,
            "User-Agent": f"DhasuAuth-PythonClient/{cls.client_version}"
        }
        payload = {
            "hwid": cls.get_hwid()
        }
        
        try:
            response = requests.post(url, json=payload, headers=headers)
            return response.status_code, response.json()
        except Exception as e:
            return 500, {"message": str(e)}
