import customtkinter as ctk
from tkinter import messagebox
from LoginManager import LoginManager
import threading

# Set appearance and theme
ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")

class Form1(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("DhasuAuth - Professional Python Client")
        self.geometry("450x400")
        self.resizable(False, False)

        # Main Frame
        self.main_frame = ctk.CTkFrame(self, corner_radius=15)
        self.main_frame.pack(padx=20, pady=20, fill="both", expand=True)

        # Title Label
        self.label_title = ctk.CTkLabel(self.main_frame, text="DHASU AUTH", font=ctk.CTkFont(size=24, weight="bold"))
        self.label_title.pack(pady=(20, 10))

        # Username Field
        self.txt_username = ctk.CTkEntry(self.main_frame, placeholder_text="Username", width=250, height=40, corner_radius=10)
        self.txt_username.pack(pady=10)

        # Password Field
        self.txt_password = ctk.CTkEntry(self.main_frame, placeholder_text="Password (Optional)", show="*", width=250, height=40, corner_radius=10)
        self.txt_password.pack(pady=10)

        # Login Button
        self.btn_login = ctk.CTkButton(self.main_frame, text="Login with Credentials", width=250, height=45, corner_radius=10, 
                                       font=ctk.CTkFont(size=14, weight="bold"), command=self.on_login_click)
        self.btn_login.pack(pady=(20, 10))

        # HWID Button
        self.btn_login_hwid = ctk.CTkButton(self.main_frame, text="HWID Access (Auto)", width=250, height=45, corner_radius=10, 
                                            fg_color="transparent", border_width=2, text_color=("gray10", "#DCE4EE"),
                                            font=ctk.CTkFont(size=14, weight="bold"), command=self.on_login_hwid_click)
        self.btn_login_hwid.pack(pady=10)

        # Status Label
        self.lbl_status = ctk.CTkLabel(self.main_frame, text="System: Ready", font=ctk.CTkFont(size=12))
        self.lbl_status.pack(side="bottom", pady=10)

    def set_loading(self, is_loading):
        state = "disabled" if is_loading else "normal"
        self.btn_login.configure(state=state)
        self.btn_login_hwid.configure(state=state)
        self.txt_username.configure(state=state)
        self.txt_password.configure(state=state)
        if is_loading:
            self.root_cursor = self.cget("cursor")
            self.configure(cursor="wait")
        else:
            self.configure(cursor="")

    def on_login_click(self):
        username = self.txt_username.get()
        password = self.txt_password.get()

        if not username:
            messagebox.showwarning("Input Error", "Please enter a username.")
            return

        self.set_loading(True)
        self.lbl_status.configure(text="System: Authenticating...", text_color="#3B8ED0")
        
        threading.Thread(target=self.do_login, args=(username, password)).start()

    def do_login(self, username, password):
        code, result = LoginManager.login_with_password(username, password)
        self.after(0, lambda: self.finish_login(code, result))

    def finish_login(self, code, result):
        self.set_loading(False)
        if code == 200:
            self.lbl_status.configure(text="System: Access Granted", text_color="#2FA572")
            expires = result.get("expires", "N/A")
            messagebox.showinfo("Success", f"Welcome back, {self.txt_username.get()}!\nExpiry: {expires}")
        else:
            self.lbl_status.configure(text="System: Login Failed", text_color="#E74C3C")
            msg = result.get("message", "Login Failed")
            messagebox.showerror("Login Failed", msg)

    def on_login_hwid_click(self):
        self.set_loading(True)
        self.lbl_status.configure(text="System: Verifying HWID...", text_color="#3B8ED0")
        threading.Thread(target=self.do_hwid_login).start()

    def do_hwid_login(self):
        code, result = LoginManager.login_with_hwid()
        self.after(0, lambda: self.finish_hwid_login(code, result))

    def finish_hwid_login(self, code, result):
        self.set_loading(False)
        if code == 200:
            self.lbl_status.configure(text="System: HWID Authorized", text_color="#2FA572")
            name = result.get("name", "Authorized Operator")
            expires = result.get("expires", "Lifetime")
            messagebox.showinfo("Success", f"Welcome back, {name}!\nExpiry: {expires}")
        else:
            self.lbl_status.configure(text="System: Access Denied", text_color="#E74C3C")
            msg = result.get("message", "HWID Access Failed")
            messagebox.showerror("Access Denied", msg)

if __name__ == "__main__":
    app = Form1()
    app.mainloop()
