﻿using Newtonsoft.Json.Linq;
using System;
using System.IO;
using System.Net.Http;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

public static class LoginManager
{
    // Backend Configuration
    public static string backendUrl = "http://217.154.173.102:9537/api/";
    public static string appId = "7ECD1305";
    public static string appSecret = "0bf157628ad00b4376e9fc85332a0508";
    public static string localVersion = "1.0.0";

    // ✅ Get System HWID
    public static string GetHWID()
    {
        try {
            return WindowsIdentity.GetCurrent().User.Value;
        } catch {
            return "UNKNOWN_HWID";
        }
    }

    // ✅ Login with Username & Password
    public static async Task<bool> LoginWithUsernamePasswordAsync(string username, string password)
    {
        try
        {
            using (HttpClient client = new HttpClient())
            {
                // Core Identity Headers
                client.DefaultRequestHeaders.Add("App-Id", appId);
                client.DefaultRequestHeaders.Add("App-Secret", appSecret);
                client.DefaultRequestHeaders.Add("Client-Version", localVersion);
                client.DefaultRequestHeaders.Add("User-Agent", "DhasuAuth-C#Client/" + localVersion);

                string url = $"{backendUrl}license/login";
                var body = new JObject
                {
                    ["username"] = username,
                    ["password"] = password ?? "", // Allow empty password
                    ["hwid"] = GetHWID()
                };

                var content = new StringContent(body.ToString(), Encoding.UTF8, "application/json");
                var response = await client.PostAsync(url, content);
                string responseString = await response.Content.ReadAsStringAsync();
                
                JObject result;
                try {
                     result = JObject.Parse(responseString);
                } catch {
                    MessageBox.Show("Server returned invalid response.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }

                string message = result["message"]?.ToString() ?? "Authentication Failure";

                if (!response.IsSuccessStatusCode)
                {
                    string reason = result["reason"]?.ToString();
                    
                    // Specific Handling for Pause/Ban
                    if (message.Contains("Paused") || message.Contains("Banned") || message.Contains("expired"))
                    {
                         MessageBox.Show($"{message}\n\nReason: {reason ?? "Contact Support"}", "Access Denied", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    else 
                    {
                         if (!string.IsNullOrEmpty(reason))
                            message = $"{message}\n\n[Security Report]\n{reason}";
                        MessageBox.Show(message, "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    
                    return false;
                }

                if (result["success"]?.ToObject<bool>() == true)
                {
                    string expires = result["expires"]?.ToString() ?? "Lifetime";
                    string expiryDisplay = (expires == "Lifetime" || expires == "Permanent") ? "♾️ Lifetime" : expires;
                    MessageBox.Show($"Access Granted!\nOperator: {username}\nExpiry: {expiryDisplay}", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    SaveLogin(username, password);
                    return true;
                }

                return false;
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Fatal Connection Error: {ex.Message}", "System Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return false;
        }
    }

    // ✅ Login with HWID Only (Fast Whitelist)
    public static async Task<bool> LoginWithHWIDAccessAsync()
    {
        try
        {
            using (HttpClient client = new HttpClient())
            {
                // Core Identity Headers
                client.DefaultRequestHeaders.Add("App-Id", appId);
                client.DefaultRequestHeaders.Add("App-Secret", appSecret);
                client.DefaultRequestHeaders.Add("Client-Version", localVersion);
                client.DefaultRequestHeaders.Add("User-Agent", "DhasuAuth-C#Client/" + localVersion);

                string url = $"{backendUrl}license/hwid-login";
                var body = new JObject
                {
                    ["hwid"] = GetHWID()
                };

                var content = new StringContent(body.ToString(), Encoding.UTF8, "application/json");
                var response = await client.PostAsync(url, content);
                string responseString = await response.Content.ReadAsStringAsync();
                
                JObject result;
                try {
                     result = JObject.Parse(responseString);
                } catch {
                    MessageBox.Show("Server returned invalid response.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }

                string message = result["message"]?.ToString() ?? "HWID Access Failed";

                if (!response.IsSuccessStatusCode)
                {
                    string reason = result["reason"]?.ToString();
                    if (!string.IsNullOrEmpty(reason))
                        message = $"{message}\n\nReason: {reason}";
                    
                    MessageBox.Show(message, "Access Denied", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return false;
                }

                if (result["success"]?.ToObject<bool>() == true)
                {
                    string name = result["name"]?.ToString() ?? "Authorized Operator";
                    string expires = result["expires"]?.ToString() ?? "Lifetime";
                    MessageBox.Show($"Welcome back, {name}!\nSession Access: {expires}", "Whitelist Authorized", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return true;
                }

                return false;
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Fatal Connection Error: {ex.Message}", "System Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return false;
        }
    }

    // ✅ Login Save/Load
    private static string loginDataPath = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
        "DhasuAuth", "login.json"
    );

    public static void SaveLogin(string username, string password)
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(loginDataPath));
            var data = new JObject { ["username"] = username, ["password"] = password };
            File.WriteAllText(loginDataPath, data.ToString());
        }
        catch { }
    }

    public static void LoadLogin(out string username, out string password)
    {
        username = ""; password = "";
        if (File.Exists(loginDataPath))
        {
            try {
                var data = JObject.Parse(File.ReadAllText(loginDataPath));
                username = data["username"]?.ToString() ?? "";
                password = data["password"]?.ToString() ?? "";
            } catch { }
        }
    }
}
