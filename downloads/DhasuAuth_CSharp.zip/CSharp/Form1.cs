using System;
using System.Drawing;
using System.Windows.Forms;
using System.Threading.Tasks;

namespace LoginTest
{
    public partial class Form1 : Form
    {
        private TextBox txtUsername;
        private TextBox txtPassword;
        private Button btnLogin;
        private Button btnLoginHWID;
        private Label lblStatus;

        public Form1()
        {
            InitializeComponent();
            SetupUI();
        }

        private void SetupUI()
        {
            this.Text = "Login Manager Tester";
            this.Size = new Size(400, 350);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lblUser = new Label() { Text = "Username:", Location = new Point(20, 30), AutoSize = true };
            txtUsername = new TextBox() { Location = new Point(120, 27), Width = 200 };

            Label lblPass = new Label() { Text = "Password:", Location = new Point(20, 70), AutoSize = true };
            txtPassword = new TextBox() { Location = new Point(120, 67), Width = 200, PasswordChar = '*' };

            btnLogin = new Button() { Text = "Login (User/Pass)", Location = new Point(120, 110), Width = 200, Height = 30 };
            btnLogin.Click += btnLogin_Click;

            btnLoginHWID = new Button() { Text = "Login (HWID)", Location = new Point(120, 150), Width = 200, Height = 30 };
            btnLoginHWID.Click += btnLoginHWID_Click;
            
            lblStatus = new Label() { Text = "Ready", Location = new Point(20, 200), AutoSize = true, ForeColor = Color.Gray };

            this.Controls.Add(lblUser);
            this.Controls.Add(txtUsername);
            this.Controls.Add(lblPass);
            this.Controls.Add(txtPassword);
            this.Controls.Add(btnLogin);
            this.Controls.Add(btnLoginHWID);
            this.Controls.Add(lblStatus);
        }

        private async void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;

            if (string.IsNullOrWhiteSpace(username))
            {
                MessageBox.Show("Please enter a username.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            SetLoading(true);
            lblStatus.Text = "Status: Authenticating...";
            lblStatus.ForeColor = Color.Blue;

            bool success = await LoginManager.LoginWithUsernamePasswordAsync(username, password);

            if (success)
            {
                lblStatus.Text = "Status: Connected";
                lblStatus.ForeColor = Color.Green;
            }
            else
            {
                lblStatus.Text = "Status: Access Denied";
                lblStatus.ForeColor = Color.Red;
            }
            SetLoading(false);
        }

        private async void btnLoginHWID_Click(object sender, EventArgs e)
        {
            SetLoading(true);
            lblStatus.Text = "Status: Checking Whitelist...";
            lblStatus.ForeColor = Color.Blue;

            bool success = await LoginManager.LoginWithHWIDAccessAsync();

            if (success)
            {
                lblStatus.Text = "Status: Whitelisted";
                lblStatus.ForeColor = Color.Green;
            }
            else
            {
                lblStatus.Text = "Status: Not Whitelisted";
                lblStatus.ForeColor = Color.Red;
            }
            SetLoading(false);
        }

        private void SetLoading(bool isLoading)
        {
            btnLogin.Enabled = !isLoading;
            btnLoginHWID.Enabled = !isLoading;
            txtUsername.Enabled = !isLoading;
            txtPassword.Enabled = !isLoading;
            Cursor = isLoading ? Cursors.WaitCursor : Cursors.Default;
        }
    }
}
