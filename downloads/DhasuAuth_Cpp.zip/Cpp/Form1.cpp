#include <windows.h>
#include <commctrl.h>
#include "LoginManager.h"
#include <string>

#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "msimg32.lib")

// --- Ultra-Modern Palette ---
#define CLR_BG          RGB(10, 10, 12)     // Deep Space Black
#define CLR_CARD        RGB(20, 20, 25)     // Slate/Navy Tinted Card
#define CLR_ACCENT      RGB(0, 212, 255)    // Neon Cyan
#define CLR_TEXT        RGB(255, 255, 255)  // Pure White
#define CLR_TEXT_DIM    RGB(130, 140, 150)  // Faded Text
#define CLR_BORDER      RGB(45, 45, 55)     // Soft Border

// Global Handles
HWND hUser, hPass, hStatus;
HBRUSH hBgBrush, hCardBrush, hAccentBrush;
HFONT hFontTitle, hFontSub, hFontInput, hFontBtn;

// Forward declarations
LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

// Helper for drawing rounded rectangles or gradients if needed
void DrawGradient(HDC hdc, RECT rect, COLORREF top, COLORREF bottom) {
    TRIVERTEX vertex[2];
    vertex[0].x = rect.left;
    vertex[0].y = rect.top;
    vertex[0].Red = GetRValue(top) << 8;
    vertex[0].Green = GetGValue(top) << 8;
    vertex[0].Blue = GetBValue(top) << 8;
    vertex[0].Alpha = 0x0000;

    vertex[1].x = rect.right;
    vertex[1].y = rect.bottom;
    vertex[1].Red = GetRValue(bottom) << 8;
    vertex[1].Green = GetGValue(bottom) << 8;
    vertex[1].Blue = GetBValue(bottom) << 8;
    vertex[1].Alpha = 0x0000;

    GRADIENT_RECT gRect;
    gRect.UpperLeft = 0;
    gRect.LowerRight = 1;

    GradientFill(hdc, vertex, 2, &gRect, 1, GRADIENT_FILL_RECT_V);
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    hBgBrush = CreateSolidBrush(CLR_BG);
    hCardBrush = CreateSolidBrush(CLR_CARD);
    hAccentBrush = CreateSolidBrush(CLR_ACCENT);

    const char CLASS_NAME[] = "DhasuAuthUltimate";
    WNDCLASSA wc = {};
    wc.lpfnWndProc = WindowProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = CLASS_NAME;
    wc.hCursor = LoadCursorA(NULL, (LPCSTR)IDC_ARROW);
    wc.hbrBackground = hBgBrush;

    RegisterClassA(&wc);

    int w = 480, h = 550;
    int screenW = GetSystemMetrics(SM_CXSCREEN);
    int screenH = GetSystemMetrics(SM_CYSCREEN);

    HWND hwnd = CreateWindowExA(
        WS_EX_LAYERED, CLASS_NAME, "DHASU AUTH - ULTIMATE",
        WS_POPUP | WS_VISIBLE | WS_SYSMENU | WS_MINIMIZEBOX,
        (screenW - w) / 2, (screenH - h) / 2, w, h,
        NULL, NULL, hInstance, NULL
    );

    SetLayeredWindowAttributes(hwnd, 0, 255, LWA_ALPHA);

    MSG msg = {};
    while (GetMessageA(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessageA(&msg);
    }

    return 0;
}

LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    switch (uMsg) {
    case WM_CREATE: {
        // Fonts
        hFontTitle = CreateFontA(48, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, "Segoe UI Variable Display");
        hFontSub = CreateFontA(18, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, "Segoe UI");
        hFontInput = CreateFontA(20, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, "Segoe UI");
        hFontBtn = CreateFontA(18, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, "Segoe UI");

        // Header Title (Static)
        HWND hTitle = CreateWindowExA(0, "STATIC", "DHASU", WS_VISIBLE | WS_CHILD | SS_CENTER, 20, 50, 440, 55, hwnd, NULL, NULL, NULL);
        SendMessageA(hTitle, WM_SETFONT, (WPARAM)hFontTitle, TRUE);

        HWND hSub = CreateWindowExA(0, "STATIC", "THE NEXT GENERATION OF AUTHENTICATION", WS_VISIBLE | WS_CHILD | SS_CENTER, 20, 110, 440, 25, hwnd, (HMENU)101, NULL, NULL);
        SendMessageA(hSub, WM_SETFONT, (WPARAM)hFontSub, TRUE);

        // Inputs
        hUser = CreateWindowExA(0, "EDIT", "", WS_VISIBLE | WS_CHILD | ES_AUTOHSCROLL, 80, 180, 320, 42, hwnd, NULL, NULL, NULL);
        SendMessageA(hUser, EM_SETCUEBANNER, TRUE, (LPARAM)L"Enter Username...");
        SendMessageA(hUser, WM_SETFONT, (WPARAM)hFontInput, TRUE);

        hPass = CreateWindowExA(0, "EDIT", "", WS_VISIBLE | WS_CHILD | ES_PASSWORD | ES_AUTOHSCROLL, 80, 235, 320, 42, hwnd, NULL, NULL, NULL);
        SendMessageA(hPass, EM_SETCUEBANNER, TRUE, (LPARAM)L"Enter Password...");
        SendMessageA(hPass, WM_SETFONT, (WPARAM)hFontInput, TRUE);

        // Buttons
        HWND hBtn1 = CreateWindowExA(0, "BUTTON", "S I G N  I N", WS_VISIBLE | WS_CHILD | BS_OWNERDRAW, 80, 310, 320, 55, hwnd, (HMENU)1, NULL, NULL);
        HWND hBtn2 = CreateWindowExA(0, "BUTTON", "W H I T E L I S T  A C C E S S", WS_VISIBLE | WS_CHILD | BS_OWNERDRAW, 80, 375, 320, 55, hwnd, (HMENU)2, NULL, NULL);

        // Status
        hStatus = CreateWindowExA(0, "STATIC", "READY FOR OPERATION", WS_VISIBLE | WS_CHILD | SS_CENTER, 20, 460, 440, 30, hwnd, NULL, NULL, NULL);
        SendMessageA(hStatus, WM_SETFONT, (WPARAM)hFontSub, TRUE);

        // Close
        HWND hClose = CreateWindowExA(0, "STATIC", "E X I T", WS_VISIBLE | WS_CHILD | SS_CENTER | SS_NOTIFY, 190, 500, 100, 25, hwnd, (HMENU)3, NULL, NULL);
        SendMessageA(hClose, WM_SETFONT, (WPARAM)hFontSub, TRUE);

        return 0;
    }

    case WM_CTLCOLORSTATIC: {
        HDC hdc = (HDC)wParam;
        SetBkMode(hdc, TRANSPARENT);
        if ((HWND)lParam == GetDlgItem(hwnd, 101)) SetTextColor(hdc, CLR_TEXT_DIM);
        else SetTextColor(hdc, CLR_TEXT);
        return (INT_PTR)hBgBrush;
    }

    case WM_CTLCOLOREDIT: {
        HDC hdc = (HDC)wParam;
        SetTextColor(hdc, CLR_TEXT);
        SetBkColor(hdc, CLR_CARD);
        return (INT_PTR)hCardBrush;
    }

    case WM_DRAWITEM: {
        LPDRAWITEMSTRUCT pdis = (LPDRAWITEMSTRUCT)lParam;
        if (pdis->CtlType == ODT_BUTTON) {
            bool pressed = (pdis->itemState & ODS_SELECTED);
            HBRUSH btnBrush = pressed ? CreateSolidBrush(RGB(0, 180, 220)) : hAccentBrush;
            FillRect(pdis->hDC, &pdis->rcItem, btnBrush);
            if (pressed) DeleteObject(btnBrush);

            SetTextColor(pdis->hDC, CLR_BG);
            SetBkMode(pdis->hDC, TRANSPARENT);
            SelectObject(pdis->hDC, hFontBtn);

            char buf[100];
            GetWindowTextA(pdis->hwndItem, buf, 100);
            DrawTextA(pdis->hDC, buf, -1, &pdis->rcItem, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
            return TRUE;
        }
        break;
    }

    case WM_COMMAND: {
        int id = LOWORD(wParam);
        if (id == 1) { // Login
            char user[100], pass[100];
            GetWindowTextA(hUser, user, 100);
            GetWindowTextA(hPass, pass, 100);

            if (strlen(user) == 0) {
                MessageBoxA(hwnd, "Please enter your identity.", "Terminal", MB_OK | MB_ICONEXCLAMATION);
                return 0;
            }

            SetWindowTextA(hStatus, "VERIFYING ENCRYPTION...");
            if (LoginManager::LoginWithPassword(user, pass)) {
                SetWindowTextA(hStatus, "IDENTITY VERIFIED. ACCESS GRANTED.");
                MessageBoxA(hwnd, "Identity Confirmed. Welcome back.", "Access Protocol", MB_ICONINFORMATION);
            } else {
                SetWindowTextA(hStatus, "IDENTITY REJECTED.");
                MessageBoxA(hwnd, "Invalid Credentials.", "Security Alert", MB_ICONERROR);
            }
        }
        else if (id == 2) { // HWID
            SetWindowTextA(hStatus, "SCANNING HARDWARE SIGNATURE...");
            if (LoginManager::LoginWithHWID()) {
                SetWindowTextA(hStatus, "SIGNATURE MATCHED. PROCEED.");
                MessageBoxA(hwnd, "Device Recognized.", "Security Protocol", MB_ICONINFORMATION);
            } else {
                SetWindowTextA(hStatus, "SIGNATURE NOT FOUND.");
                MessageBoxA(hwnd, "Unauthorized Device.", "Security Alert", MB_ICONERROR);
            }
        }
        else if (id == 3) {
            PostQuitMessage(0);
        }
        return 0;
    }

    case WM_NCHITTEST: {
        LRESULT hit = DefWindowProcA(hwnd, uMsg, wParam, lParam);
        if (hit == HTCLIENT) return HTCAPTION;
        return hit;
    }

    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hwnd, &ps);
        // Paint any custom dividers or accents here if needed
        EndPaint(hwnd, &ps);
        return 0;
    }

    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcA(hwnd, uMsg, wParam, lParam);
}
