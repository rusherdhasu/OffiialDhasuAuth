#include "LoginManager.h"
#include <iostream>

void Header() {
    std::cout << "========================================\n";
    std::cout << "     DHASU AUTH - C++ CLIENT TESTER     \n";
    std::cout << "========================================\n";
    std::cout << "HWID: " << LoginManager::GetHWID() << "\n\n";
}

int main() {
    Header();

    std::cout << "1. Login (User/Pass)\n";
    std::cout << "2. Login (HWID Whitelist)\n";
    std::cout << "Select Option: ";
    
    int choice;
    std::cin >> choice;

    if (choice == 1) {
        std::string user, pass;
        std::cout << "Username: "; std::cin >> user;
        std::cout << "Password: "; std::cin >> pass;

        if (LoginManager::LoginWithPassword(user, pass)) {
            std::cout << "\n[+] Access Granted!\n";
        } else {
            std::cout << "\n[-] Access Denied.\n";
        }
    } else if (choice == 2) {
        if (LoginManager::LoginWithHWID()) {
            std::cout << "\n[+] HWID Authorized!\n";
        } else {
            std::cout << "\n[-] HWID Not Authorized.\n";
        }
    }

    std::cout << "\nPress any key to exit...";
    std::string dummy; std::cin >> dummy;
    return 0;
}
