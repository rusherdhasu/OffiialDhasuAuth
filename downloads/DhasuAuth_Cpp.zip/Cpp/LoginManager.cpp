#include "LoginManager.h"
#include <windows.h>
#include <wininet.h>
#include <iostream>

#pragma comment(lib, "wininet.lib")

std::string LoginManager::backend_url = "217.154.173.102";
std::string LoginManager::app_id = "7ECD1305";
std::string LoginManager::app_secret = "0bf157628ad00b4376e9fc85332a0508";

std::string LoginManager::GetHWID() {
    HW_PROFILE_INFOA hwProfileInfo;
    if (GetCurrentHwProfileA(&hwProfileInfo)) {
        return hwProfileInfo.szHwProfileGuid;
    }
    return "{UNKNOWN-HWID-CP}";
}

std::string LoginManager::HttpRequest(std::string path, std::string payload) {
    HINTERNET hSession = InternetOpenA("DhasuAuth-CppClient/1.0", INTERNET_OPEN_TYPE_DIRECT, NULL, NULL, 0);
    if (!hSession) return "{\"success\":false, \"message\":\"Session Error\"}";

    HINTERNET hConnect = InternetConnectA(hSession, backend_url.c_str(), 9537, NULL, NULL, INTERNET_SERVICE_HTTP, 0, 0);
    if (!hConnect) { InternetCloseHandle(hSession); return "{\"success\":false, \"message\":\"Connect Error\"}"; }

    const char* acceptTypes[] = { "application/json", NULL };
    HINTERNET hRequest = HttpOpenRequestA(hConnect, "POST", path.c_str(), NULL, NULL, acceptTypes, INTERNET_FLAG_RELOAD, 0);
    
    std::string headers = "App-Id: " + app_id + "\r\nApp-Secret: " + app_secret + "\r\nContent-Type: application/json\r\n";
    
    BOOL sent = HttpSendRequestA(hRequest, headers.c_str(), (DWORD)headers.length(), (LPVOID)payload.c_str(), (DWORD)payload.length());
    
    std::string response = "";
    if (sent) {
        char buffer[1024];
        DWORD bytesRead;
        while (InternetReadFile(hRequest, buffer, sizeof(buffer), &bytesRead) && bytesRead > 0) {
            response.append(buffer, bytesRead);
        }
    } else {
        response = "{\"success\":false, \"message\":\"Request Error\"}";
    }

    InternetCloseHandle(hRequest);
    InternetCloseHandle(hConnect);
    InternetCloseHandle(hSession);
    return response;
}

bool LoginManager::LoginWithPassword(std::string username, std::string password) {
    std::string payload = "{\"username\":\"" + username + "\", \"password\":\"" + password + "\", \"hwid\":\"" + GetHWID() + "\"}";
    std::string res = HttpRequest("/api/license/login", payload);
    return (res.find("\"success\":true") != std::string::npos);
}

bool LoginManager::LoginWithHWID() {
    std::string payload = "{\"hwid\":\"" + GetHWID() + "\"}";
    std::string res = HttpRequest("/api/license/hwid-login", payload);
    return (res.find("\"success\":true") != std::string::npos);
}
