#ifndef LOGIN_MANAGER_H
#define LOGIN_MANAGER_H

#include <string>

class LoginManager {
public:
    static std::string backend_url;
    static std::string app_id;
    static std::string app_secret;

    static std::string GetHWID();
    static std::string HttpRequest(std::string path, std::string payload);
    static bool LoginWithPassword(std::string username, std::string password);
    static bool LoginWithHWID();
};

#endif
